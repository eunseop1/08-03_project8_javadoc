import matplotlib.pyplot as plt

# plot() 함수는 리스트의 값들이 y 값들이라고 가정하고, x 값 [0, 1, 2, 3]을 자동으로 만들어냅니다.
plt.plot([1, 3, 6, 4])  # (0,1), (1,3), (2,6), (3,4) 좌표가 생성되고
plt.show()  # 그래프를 보여준다.

